# Autostart your applications

A Python package to autostart your desktop application when your system turn-on

## Usage

Following query on terminal will help you to enable autostart your application and open your terminal where your script or exe file.

```
Autostart-app -f <filename> -s <ful path of your script.py or executable name > -i <icon name>

```
